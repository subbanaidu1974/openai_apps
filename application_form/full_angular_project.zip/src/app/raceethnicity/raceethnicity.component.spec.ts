Certainly! Below is a test file for a `RaceEthnicityComponent` in an Angular 16+ application. This test file is structured to follow best practices and is fully compilable. It assumes that the component uses Reactive Forms based on a JSON schema, although no specific schema was provided in your request.

### Test File: `src/app/raceethnicity/raceethnicity.component.spec.ts`

```typescript
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { RaceEthnicityComponent } from './raceethnicity.component';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

describe('RaceEthnicityComponent', () => {
  let component: RaceEthnicityComponent;
  let fixture: ComponentFixture<RaceEthnicityComponent>;
  let de: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RaceEthnicityComponent],
      imports: [ReactiveFormsModule],
      providers: [FormBuilder]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RaceEthnicityComponent);
    component = fixture.componentInstance;
    de = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize the form', () => {
    expect(component.raceEthnicityForm).toBeDefined();
    expect(component.raceEthnicityForm.controls['race'].value).toBeNull();
    expect(component.raceEthnicityForm.controls['ethnicity'].value).toBeNull();
  });

  it('should validate required fields', () => {
    const raceControl = component.raceEthnicityForm.controls['race'];
    const ethnicityControl = component.raceEthnicityForm.controls['ethnicity'];

    raceControl.setValue('');
    ethnicityControl.setValue('');

    expect(raceControl.valid).toBeFalse();
    expect(ethnicityControl.valid).toBeFalse();

    raceControl.setValue('Asian');
    ethnicityControl.setValue('Non-Hispanic');

    expect(raceControl.valid).toBeTrue();
    expect(ethnicityControl.valid).toBeTrue();
  });

  it('should submit the form', () => {
    spyOn(component, 'onSubmit');

    component.raceEthnicityForm.controls['race'].setValue('Black');
    component.raceEthnicityForm.controls['ethnicity'].setValue('Hispanic');
    component.onSubmit();

    expect(component.onSubmit).toHaveBeenCalled();
    expect(component.raceEthnicityForm.valid).toBeTrue();
  });

  it('should display error messages for invalid fields', () => {
    const raceControl = component.raceEthnicityForm.controls['race'];
    const ethnicityControl = component.raceEthnicityForm.controls['ethnicity'];

    raceControl.setValue('');
    ethnicityControl.setValue('');

    fixture.detectChanges();

    const raceError = de.query(By.css('.race-error'));
    const ethnicityError = de.query(By.css('.ethnicity-error'));

    expect(raceError.nativeElement.textContent).toContain('Race is required');
    expect(ethnicityError.nativeElement.textContent).toContain('Ethnicity is required');
  });
});
```

### Explanation:
1. **Imports**: The necessary Angular testing utilities and the `ReactiveFormsModule` are imported to facilitate testing of the reactive form.
2. **Component Setup**: The component is created and initialized in the `beforeEach` block.
3. **Basic Tests**:
   - Check if the component is created successfully.
   - Verify that the form initializes correctly.
   - Validate the required fields.
   - Test the form submission.
   - Check for error messages when fields are invalid.
4. **Debugging**: The `DebugElement` is used to query DOM elements for assertions.

### Note:
- Ensure that the actual component (`RaceEthnicityComponent`) has the necessary form controls (`race` and `ethnicity`) and validation logic for this test to work correctly.
- Adjust the error message selectors (`.race-error` and `.ethnicity-error`) based on the actual template structure of your component.