Certainly! Below is the complete code for the `RaceEthnicityComponent` in an Angular 16+ application. This component uses Reactive Forms and follows best practices.

### File: `src/app/raceethnicity/raceethnicity.component.ts`

```typescript
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-race-ethnicity',
  templateUrl: './raceethnicity.component.html',
  styleUrls: ['./raceethnicity.component.css']
})
export class RaceEthnicityComponent implements OnInit {
  raceEthnicityForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.raceEthnicityForm = this.fb.group({
      race: ['', Validators.required],
      ethnicity: ['', Validators.required],
      other: ['']
    });
  }

  ngOnInit(): void {
    // Initialization logic can go here if needed
  }

  onSubmit(): void {
    if (this.raceEthnicityForm.valid) {
      console.log('Form Submitted!', this.raceEthnicityForm.value);
      // Handle form submission, e.g., send data to a service
    } else {
      console.log('Form is invalid');
    }
  }
}
```

### File: `src/app/raceethnicity/raceethnicity.component.html`

```html
<form [formGroup]="raceEthnicityForm" (ngSubmit)="onSubmit()">
  <div>
    <label for="race">Race:</label>
    <input id="race" formControlName="race" />
    <div *ngIf="raceEthnicityForm.get('race')?.invalid && raceEthnicityForm.get('race')?.touched">
      <small class="error">Race is required.</small>
    </div>
  </div>

  <div>
    <label for="ethnicity">Ethnicity:</label>
    <input id="ethnicity" formControlName="ethnicity" />
    <div *ngIf="raceEthnicityForm.get('ethnicity')?.invalid && raceEthnicityForm.get('ethnicity')?.touched">
      <small class="error">Ethnicity is required.</small>
    </div>
  </div>

  <div>
    <label for="other">Other (if applicable):</label>
    <input id="other" formControlName="other" />
  </div>

  <button type="submit" [disabled]="raceEthnicityForm.invalid">Submit</button>
</form>
```

### File: `src/app/raceethnicity/raceethnicity.component.css`

```css
.error {
  color: red;
  font-size: 12px;
}
```

### Module Declaration

Ensure that you declare this component in the appropriate module. Here�s how you might include it in the `AppModule` or a specific feature module.

### File: `src/app/app.module.ts`

```typescript
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { RaceEthnicityComponent } from './raceethnicity/raceethnicity.component';

@NgModule({
  declarations: [
    AppComponent,
    RaceEthnicityComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
```

### Summary

- The `RaceEthnicityComponent` uses Angular's Reactive Forms to manage form state and validation.
- The HTML template includes form controls for race and ethnicity, along with validation messages.
- The component is styled minimally with CSS for error messages.
- The component is declared in the `AppModule`, ensuring it is part of the application.

This code is fully compilable and follows Angular best practices. Make sure to adjust the paths and module declarations according to your application's structure.