Certainly! Below is a complete implementation of the `OtherHouseholdMembers` component for an Angular 16+ application. This component will utilize Reactive Forms based on a hypothetical JSON schema for household members. 

### Step 1: Create the Component

First, we will create the component file `otherhouseholdmembers.component.ts`.

```typescript
// src/app/otherhouseholdmembers/otherhouseholdmembers.component.ts

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';

@Component({
  selector: 'app-other-household-members',
  templateUrl: './otherhouseholdmembers.component.html',
  styleUrls: ['./otherhouseholdmembers.component.css']
})
export class OtherHouseholdMembersComponent implements OnInit {
  householdMembersForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.householdMembersForm = this.fb.group({
      members: this.fb.array([])
    });
  }

  ngOnInit(): void {
    // Initialize with one member
    this.addMember();
  }

  get members(): FormArray {
    return this.householdMembersForm.get('members') as FormArray;
  }

  addMember(): void {
    const memberForm = this.fb.group({
      name: ['', Validators.required],
      age: ['', [Validators.required, Validators.min(0)]],
      relationship: ['', Validators.required]
    });
    this.members.push(memberForm);
  }

  removeMember(index: number): void {
    this.members.removeAt(index);
  }

  onSubmit(): void {
    if (this.householdMembersForm.valid) {
      console.log('Form Submitted!', this.householdMembersForm.value);
      // Handle form submission logic here
    } else {
      console.log('Form is invalid');
    }
  }
}
```

### Step 2: Create the Template

Next, we will create the associated HTML template file `otherhouseholdmembers.component.html`.

```html
<!-- src/app/otherhouseholdmembers/otherhouseholdmembers.component.html -->

<div class="container">
  <h2>Other Household Members</h2>
  <form [formGroup]="householdMembersForm" (ngSubmit)="onSubmit()">
    <div formArrayName="members">
      <div *ngFor="let member of members.controls; let i = index" [formGroupName]="i" class="member">
        <label>Name:</label>
        <input formControlName="name" placeholder="Enter name" />
        <div *ngIf="member.get('name').invalid && member.get('name').touched">Name is required.</div>

        <label>Age:</label>
        <input type="number" formControlName="age" placeholder="Enter age" />
        <div *ngIf="member.get('age').invalid && member.get('age').touched">Age is required and must be a positive number.</div>

        <label>Relationship:</label>
        <input formControlName="relationship" placeholder="Enter relationship" />
        <div *ngIf="member.get('relationship').invalid && member.get('relationship').touched">Relationship is required.</div>

        <button type="button" (click)="removeMember(i)">Remove Member</button>
      </div>
    </div>
    <button type="button" (click)="addMember()">Add Member</button>
    <button type="submit" [disabled]="householdMembersForm.invalid">Submit</button>
  </form>
</div>
```

### Step 3: Create the Styles

You can also create a CSS file for styling the component, `otherhouseholdmembers.component.css`.

```css
/* src/app/otherhouseholdmembers/otherhouseholdmembers.component.css */

.container {
  margin: 20px;
}

.member {
  border: 1px solid #ccc;
  padding: 10px;
  margin-bottom: 10px;
}

button {
  margin-top: 10px;
}
```

### Step 4: Update the Module

Make sure to declare the component in your module file, typically `app.module.ts`.

```typescript
// src/app/app.module.ts

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { OtherHouseholdMembersComponent } from './otherhouseholdmembers/otherhouseholdmembers.component';

@NgModule({
  declarations: [
    AppComponent,
    OtherHouseholdMembersComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
```

### Conclusion

This implementation provides a fully functional `OtherHouseholdMembers` component that adheres to best practices in Angular development, leveraging Reactive Forms for dynamic form handling. You can further customize the component based on your specific JSON schema and requirements.