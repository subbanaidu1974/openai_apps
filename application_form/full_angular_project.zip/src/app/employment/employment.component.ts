Certainly! Below is a complete Angular component for an Employment section, which uses Reactive Forms. This component will allow users to input their employment details.

### `src/app/employment/employment.component.ts`

```typescript
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-employment',
  templateUrl: './employment.component.html',
  styleUrls: ['./employment.component.css']
})
export class EmploymentComponent implements OnInit {
  employmentForm: FormGroup;

  constructor(private fb: FormBuilder) {
    // Initialize the form with FormBuilder
    this.employmentForm = this.fb.group({
      companyName: ['', Validators.required],
      jobTitle: ['', Validators.required],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      responsibilities: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    // Any initialization logic can go here
  }

  onSubmit(): void {
    if (this.employmentForm.valid) {
      console.log('Employment Details:', this.employmentForm.value);
      // Here you can handle the form submission, e.g., sending data to a server
    } else {
      console.log('Form is invalid');
    }
  }
}
```

### `src/app/employment/employment.component.html`

```html
<form [formGroup]="employmentForm" (ngSubmit)="onSubmit()">
  <div>
    <label for="companyName">Company Name:</label>
    <input id="companyName" formControlName="companyName" />
    <div *ngIf="employmentForm.get('companyName')?.invalid && employmentForm.get('companyName')?.touched">
      Company Name is required.
    </div>
  </div>
  
  <div>
    <label for="jobTitle">Job Title:</label>
    <input id="jobTitle" formControlName="jobTitle" />
    <div *ngIf="employmentForm.get('jobTitle')?.invalid && employmentForm.get('jobTitle')?.touched">
      Job Title is required.
    </div>
  </div>
  
  <div>
    <label for="startDate">Start Date:</label>
    <input type="date" id="startDate" formControlName="startDate" />
    <div *ngIf="employmentForm.get('startDate')?.invalid && employmentForm.get('startDate')?.touched">
      Start Date is required.
    </div>
  </div>
  
  <div>
    <label for="endDate">End Date:</label>
    <input type="date" id="endDate" formControlName="endDate" />
    <div *ngIf="employmentForm.get('endDate')?.invalid && employmentForm.get('endDate')?.touched">
      End Date is required.
    </div>
  </div>
  
  <div>
    <label for="responsibilities">Responsibilities:</label>
    <textarea id="responsibilities" formControlName="responsibilities"></textarea>
    <div *ngIf="employmentForm.get('responsibilities')?.invalid && employmentForm.get('responsibilities')?.touched">
      Responsibilities are required.
    </div>
  </div>
  
  <button type="submit" [disabled]="employmentForm.invalid">Submit</button>
</form>
```

### `src/app/employment/employment.component.css`

```css
/* Add any styles specific to the Employment component here */
form {
  display: flex;
  flex-direction: column;
  max-width: 400px;
  margin: auto;
}

div {
  margin-bottom: 15px;
}

label {
  margin-bottom: 5px;
}

input, textarea {
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  padding: 10px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:disabled {
  background-color: #ccc;
}
```

### Module Declaration

Make sure to declare the `EmploymentComponent` in your module, typically in `src/app/app.module.ts`:

```typescript
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { EmploymentComponent } from './employment/employment.component';

@NgModule({
  declarations: [
    AppComponent,
    EmploymentComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
```

### Summary

This code provides a fully functional Employment component in Angular that utilizes Reactive Forms. It includes form validation and a simple submission handler. Make sure to adapt the styles and functionality as needed for your specific application.