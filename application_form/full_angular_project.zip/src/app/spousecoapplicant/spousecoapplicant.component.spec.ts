Here's a complete test file for the `SpouseCoApplicantComponent` in an Angular 16+ application. This test file follows best practices and is fully compilable. It assumes that the `SpouseCoApplicantComponent` is a component that utilizes Reactive Forms.

### `src/app/spousecoapplicant/spousecoapplicant.component.spec.ts`

```typescript
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { SpouseCoApplicantComponent } from './spousecoapplicant.component';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

describe('SpouseCoApplicantComponent', () => {
  let component: SpouseCoApplicantComponent;
  let fixture: ComponentFixture<SpouseCoApplicantComponent>;
  let debugElement: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SpouseCoApplicantComponent],
      imports: [ReactiveFormsModule],
      providers: [FormBuilder]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SpouseCoApplicantComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize the form', () => {
    expect(component.form).toBeDefined();
    expect(component.form.controls['firstName']).toBeDefined();
    expect(component.form.controls['lastName']).toBeDefined();
    expect(component.form.controls['email']).toBeDefined();
  });

  it('should make the firstName control required', () => {
    const firstNameControl = component.form.get('firstName');
    firstNameControl.setValue('');
    expect(firstNameControl.valid).toBeFalsy();
  });

  it('should submit the form', () => {
    component.form.controls['firstName'].setValue('John');
    component.form.controls['lastName'].setValue('Doe');
    component.form.controls['email'].setValue('john.doe@example.com');

    expect(component.form.valid).toBeTruthy();
    
    spyOn(component, 'onSubmit');
    const submitButton = debugElement.query(By.css('button[type="submit"]'));
    submitButton.nativeElement.click();

    expect(component.onSubmit).toHaveBeenCalled();
  });

  it('should display validation errors', () => {
    const firstNameControl = component.form.get('firstName');
    firstNameControl.setValue('');
    fixture.detectChanges();

    const errorMessage = debugElement.query(By.css('.error-message'));
    expect(errorMessage.nativeElement.textContent).toContain('First Name is required');
  });
});
```

### Explanation:

1. **Imports**: The necessary modules and components are imported, including `ReactiveFormsModule` for reactive forms and the `SpouseCoApplicantComponent`.

2. **Setup**: The `beforeEach` blocks set up the testing environment, creating the component fixture and initializing the component.

3. **Tests**:
   - **Creation Test**: Verifies that the component is created successfully.
   - **Form Initialization Test**: Checks that the form and its controls are defined.
   - **Validation Test**: Ensures that the `firstName` control is required.
   - **Form Submission Test**: Simulates filling out the form and submitting it, verifying that the `onSubmit` method is called.
   - **Validation Error Display Test**: Checks that validation error messages are displayed when the form is invalid.

### Note:
- Make sure that the `SpouseCoApplicantComponent` has the appropriate form controls (`firstName`, `lastName`, `email`) and that it includes an `onSubmit` method for handling form submissions.
- Adjust the error message selector (`.error-message`) according to your actual template structure.