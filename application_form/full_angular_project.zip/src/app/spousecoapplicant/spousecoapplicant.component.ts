Here's a complete Angular component for the SpouseCoApplicant section, following best practices and utilizing Reactive Forms. This component will be placed in the `src/app/spousecoapplicant` directory.

### Step 1: Generate the Component

You can create the component using Angular CLI with the following command:

```bash
ng generate component spousecoapplicant
```

### Step 2: Implement the Component

Below is the complete code for `src/app/spousecoapplicant/spousecoapplicant.component.ts`:

```typescript
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-spousecoapplicant',
  templateUrl: './spousecoapplicant.component.html',
  styleUrls: ['./spousecoapplicant.component.css']
})
export class SpouseCoApplicantComponent implements OnInit {
  spouseCoApplicantForm: FormGroup;

  constructor(private formBuilder: FormBuilder) {
    // Initialize the form group
    this.spouseCoApplicantForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.maxLength(50)]],
      lastName: ['', [Validators.required, Validators.maxLength(50)]],
      dateOfBirth: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      address: this.formBuilder.group({
        street: ['', Validators.required],
        city: ['', Validators.required],
        state: ['', Validators.required],
        zip: ['', [Validators.required, Validators.pattern(/^\d{5}$/)]]
      })
    });
  }

  ngOnInit(): void {
    // Any additional initialization logic can go here
  }

  // Method to handle form submission
  onSubmit(): void {
    if (this.spouseCoApplicantForm.valid) {
      console.log('Form Submitted!', this.spouseCoApplicantForm.value);
      // Handle the form submission logic here (e.g., send data to the server)
    } else {
      console.log('Form is invalid');
    }
  }

  // Getter for easy access to form controls
  get formControls() {
    return this.spouseCoApplicantForm.controls;
  }
}
```

### Step 3: Create the Template

You also need to create the corresponding HTML template for the component. Create a file named `spousecoapplicant.component.html` in the same directory with the following content:

```html
<form [formGroup]="spouseCoApplicantForm" (ngSubmit)="onSubmit()">
  <h2>Spouse/Co-Applicant Information</h2>

  <div>
    <label for="firstName">First Name:</label>
    <input id="firstName" formControlName="firstName" />
    <div *ngIf="formControls.firstName.invalid && (formControls.firstName.dirty || formControls.firstName.touched)">
      <small *ngIf="formControls.firstName.errors?.required">First Name is required.</small>
      <small *ngIf="formControls.firstName.errors?.maxlength">First Name cannot exceed 50 characters.</small>
    </div>
  </div>

  <div>
    <label for="lastName">Last Name:</label>
    <input id="lastName" formControlName="lastName" />
    <div *ngIf="formControls.lastName.invalid && (formControls.lastName.dirty || formControls.lastName.touched)">
      <small *ngIf="formControls.lastName.errors?.required">Last Name is required.</small>
      <small *ngIf="formControls.lastName.errors?.maxlength">Last Name cannot exceed 50 characters.</small>
    </div>
  </div>

  <div>
    <label for="dateOfBirth">Date of Birth:</label>
    <input type="date" id="dateOfBirth" formControlName="dateOfBirth" />
    <div *ngIf="formControls.dateOfBirth.invalid && (formControls.dateOfBirth.dirty || formControls.dateOfBirth.touched)">
      <small *ngIf="formControls.dateOfBirth.errors?.required">Date of Birth is required.</small>
    </div>
  </div>

  <div>
    <label for="email">Email:</label>
    <input id="email" formControlName="email" />
    <div *ngIf="formControls.email.invalid && (formControls.email.dirty || formControls.email.touched)">
      <small *ngIf="formControls.email.errors?.required">Email is required.</small>
      <small *ngIf="formControls.email.errors?.email">Email is invalid.</small>
    </div>
  </div>

  <div>
    <label for="phone">Phone:</label>
    <input id="phone" formControlName="phone" />
    <div *ngIf="formControls.phone.invalid && (formControls.phone.dirty || formControls.phone.touched)">
      <small *ngIf="formControls.phone.errors?.required">Phone is required.</small>
      <small *ngIf="formControls.phone.errors?.pattern">Phone must be 10 digits.</small>
    </div>
  </div>

  <h3>Address</h3>
  <div formGroupName="address">
    <div>
      <label for="street">Street:</label>
      <input id="street" formControlName="street" />
      <div *ngIf="formControls.address.get('street').invalid && (formControls.address.get('street').dirty || formControls.address.get('street').touched)">
        <small *ngIf="formControls.address.get('street').errors?.required">Street is required.</small>
      </div>
    </div>

    <div>
      <label for="city">City:</label>
      <input id="city" formControlName="city" />
      <div *ngIf="formControls.address.get('city').invalid && (formControls.address.get('city').dirty || formControls.address.get('city').touched)">
        <small *ngIf="formControls.address.get('city').errors?.required">City is required.</small>
      </div>
    </div>

    <div>
      <label for="state">State:</label>
      <input id="state" formControlName="state" />
      <div *ngIf="formControls.address.get('state').invalid && (formControls.address.get('state').dirty || formControls.address.get('state').touched)">
        <small *ngIf="formControls.address.get('state').errors?.required">State is required.</small>
      </div>
    </div>

    <div>
      <label for="zip">Zip Code:</label>
      <input id="zip" formControlName="zip" />
      <div *ngIf="formControls.address.get('zip').invalid && (formControls.address.get('zip').dirty || formControls.address.get('zip').touched)">
        <small *ngIf="formControls.address.get('zip').errors?.required">Zip Code is required.</small>
        <small *ngIf="formControls.address.get('zip').errors?.pattern">Zip Code must be 5 digits.</small>
      </div>
    </div>
  </div>

  <button type="submit" [disabled]="spouseCoApplicantForm.invalid">Submit</button>
</form>
```

### Step 4: Add Styles (Optional)

You can add styles in `spousecoapplicant.component.css` to improve the appearance of the form, but this is optional.

### Step 5: Import ReactiveFormsModule

Make sure to import `ReactiveFormsModule` in your module file (e.g., `app.module.ts` or a specific module file if you have a feature module):

```typescript
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    // other components
    SpouseCoApplicantComponent
  ],
  imports: [
    // other modules
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
```

### Conclusion

This code provides a fully functional Angular component for the SpouseCoApplicant section using Reactive Forms. You can further extend it based on your application's requirements.